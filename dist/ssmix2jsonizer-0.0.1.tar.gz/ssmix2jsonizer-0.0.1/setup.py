from setuptools import setup

setup(name='ssmix2jsonizer',
version='0.0.1',
packages = ['ssmix2jsonizer'])